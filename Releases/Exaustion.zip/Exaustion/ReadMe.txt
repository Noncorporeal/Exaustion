Exhaustion is about the cost of exploration. You can choose to explore any portion 
of the world you would like, but the cost of such exploration comes from your health. 
Can you find your way through the maze before you succumb to exhaustion?
--------------------------------------------------------------------------------------

Controls: 
WASD to move
Left Click to attack
Hold Left shift to enter Discover Mode
Click and Drag in Discover Mode to reveal more of the map.

--------------------------------------------------------------------------------------
Assets Used:
Desert Sand Dungeon Tileset - Desert Sand! Dungeon Tileset by PetricakeGames
(https://petricakegames.itch.io/desert-sand-dungeon-tileset?download)
Dungeon Tileset II - 16x16 DungeonTileset II by 0x72 
(https://0x72.itch.io/dungeontileset-ii?download)
Music and audio from OpenGameArt.org